package GamePlay;

public class GamePlayMedium extends GamePlayEasy {
	
	public GamePlayMedium(String s)
	{
		super(s);
		super.LevelCheck = "Medium";
	}
	
	
}
