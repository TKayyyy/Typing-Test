package GamePlay; 

public class GamePlayHard extends GamePlayEasy {
	
	public GamePlayHard(String s)
	{
		super(s);
		super.LevelCheck = "Hard";
	}

}
