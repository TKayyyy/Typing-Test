package GameTesting;
import GameStartandOver.StartGame;

public class GameTesting {

	public static void main(String[] args) {
		new StartGame("Typing Test");
	}

}
